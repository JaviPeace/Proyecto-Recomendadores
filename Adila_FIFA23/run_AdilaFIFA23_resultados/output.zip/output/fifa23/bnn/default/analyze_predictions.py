import os
import pickle
import pandas as pd
import torch
import matplotlib.pyplot as plt
import numpy as np

# === RUTAS ===
PREDICTIONS_PATH = "f0.test.pred"
MEAN_EVAL_CSV_PATH = "f0.test.pred.eval.mean.csv"
STATS_PATH = "rerank/popularity/stats.pkl"
LABELS_PATH = "rerank/popularity/labels.csv"

# === CARGA DE PREDICCIONES ===
print("Cargando predicciones...")
with open(PREDICTIONS_PATH, "rb") as f:
    preds = torch.load(f)

print(f"Total de predicciones cargadas: {len(preds)}")
print(f"Ejemplo de predicción (top 5 probabilidades):\n{preds[0].numpy()[:5]}")

# === CARGA DE EVALUACIÓN ===
print("\nCargando métricas de evaluación promedio...")
df_eval = pd.read_csv(MEAN_EVAL_CSV_PATH)
print(df_eval)

# === CARGA DE STATS ===
print("\nCargando estadísticas de los equipos...")
with open(STATS_PATH, "rb") as f:
    stats = pickle.load(f)

print(f"Total de estadísticas: {len(stats)}")
print(f"Ejemplo: {list(stats.items())[0]}")

# === CARGA DE ETIQUETAS ===
print("\nCargando etiquetas verdaderas...")
labels = pd.read_csv(LABELS_PATH, converters={"members": eval})
print(f"Total de equipos en test: {len(labels)}")
print(f"Ejemplo (primer equipo):\n{labels.iloc[0]}")

# === MÉTRICA MANUAL: PRECISION@K ===
def precision_at_k(preds, labels, k=10):
    total = len(preds)
    correct = 0
    for i in range(total):
        top_k = preds[i].numpy().argsort()[::-1][:k]

        true_members = set(labels.iloc[i]["members"])

        hits = len([m for m in top_k if m in true_members])
        correct += hits / k
    return correct / total

print("\nCalculando Precision@10...")
prec_at_10 = precision_at_k(preds, labels, k=22)
print(f"Precision@22: {prec_at_10:.4f}")

# === VISUALIZACIÓN (opcional) ===
plt.figure(figsize=(8, 4))
plt.bar(["Precision@10"], [prec_at_10])
plt.ylim(0, 1)
plt.title("Precisión @22 sobre el conjunto de test")
plt.ylabel("Precision")
plt.grid(True)
plt.tight_layout()
plt.show()

